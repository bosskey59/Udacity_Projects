Neigborhood Map
===============================

Project Overview:
You will develop a single page application featuring a map of your neighborhood or a neighborhood you would like to visit. You will then add functionality to this map including highlighted locations, third-party data about those locations and various ways to browse the content.

How to Run:
1) Download Zip file or clone git repo. 
2) Open Index.html with a web browser.
3) Enjoy!

Credits:
// ajax request solved by referencing https://gist.github.com/mnemonicflow/1b90ef0d294c692d24458b8378054c81

