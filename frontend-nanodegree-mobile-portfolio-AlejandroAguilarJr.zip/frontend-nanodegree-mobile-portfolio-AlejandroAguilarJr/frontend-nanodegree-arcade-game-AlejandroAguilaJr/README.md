frontend-nanodegree-arcade-game
===============================

Project Description:
This is the third project for Udacity's Front-End Developer Nanodegree progrom. Create a frogger-style game using Object Oriented JavaScript and HTML5 Canvas. Students are provided with images and a game loop engine, and must build the game from there.

How to Play:
Use the arrow keys to navigate towards the water, avoid the bugs on the way! If you make it you score a point, else you get reset to the start position.

How to Run:
1) Download Zip file or clone git repo. 
2) Open Index.html with a web browser.
3) Enjoy the arcade game!